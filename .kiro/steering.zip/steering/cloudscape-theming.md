---
inclusion: fileMatch
fileMatchPattern: "admin-panel/**/*.{css,js,jsx,ts,tsx}"
---

# Cloudscape Design System - Custom Theming Guide

## Overview

Cloudscape components use CSS custom properties (design tokens) with hashed suffixes for all visual styling. To customize the theme (e.g., change accent color from blue to red), you must override the root `--color-primary-*` tokens that all components derive their colors from.

## Architecture

Cloudscape's color system works in layers:

1. **Root palette tokens**: `--color-primary-{shade}-{hash}` (e.g., `--color-primary-600-1lcy1k`)
2. **Semantic tokens**: `--color-text-button-normal-default-{hash}` → references `--color-primary-600-{hash}`
3. **Component styles**: `var(--color-text-button-normal-default-{hash}, #006ce0)`

By overriding layer 1, everything downstream changes automatically: buttons, links, focus rings, tabs, checkboxes, etc.

## How to Find Token Hashes

The hashes are version-specific. Extract them from the installed package:

```bash
grep -o "\-\-color-primary-[0-9]*-[a-z0-9]*" \
  admin-panel/node_modules/@cloudscape-design/components/internal/base-component/styles.scoped.css \
  | sort -u
```

This outputs tokens like:
```
--color-primary-50-1y05xv
--color-primary-100-f62fz9
--color-primary-400-n8h4bx
--color-primary-600-1lcy1k
--color-primary-900-a5kqrr
```

## Current AC Milan Theme Implementation

File: `admin-panel/src/theme/dark-theme.css`

The primary palette is overridden from blue to AC Milan red:

```css
:root,
.awsui-dark-mode,
[class*="awsui"] {
  --color-primary-50-1y05xv: #fff5f5 !important;
  --color-primary-100-f62fz9: #ffe0e0 !important;
  --color-primary-400-n8h4bx: #c62828 !important;   /* dark mode accent */
  --color-primary-600-1lcy1k: #AC1A2F !important;   /* light mode accent */
  --color-primary-900-a5kqrr: #5a0c18 !important;   /* hover/active states */
}
```

## Dark Mode Activation

Cloudscape has native dark mode via `applyMode(Mode.Dark)`:

```javascript
// admin-panel/src/index.js
import { applyMode, Mode } from '@cloudscape-design/global-styles';
applyMode(Mode.Dark);
```

This adds the `awsui-dark-mode` class to `<body>`, which activates all dark-mode token values automatically.

## What Does NOT Work

- **CSS variable overrides without hashes**: `--color-background-button-primary-default` won't work because Cloudscape uses hashed versions internally.
- **Class-based selectors** like `[class*="awsui_variant-primary"]`: These have low specificity and Cloudscape's own styles win.
- **Generic token names** in `.awsui-dark-mode {}`: These are ignored because the components reference the hashed versions.

## Key Token Mappings (from style-dictionary source)

From `admin-panel/cloudspace-components/components-main/style-dictionary/visual-refresh/colors.ts`:

| Component | Light Mode Token | Dark Mode Token |
|-----------|-----------------|-----------------|
| Button normal text/border | `colorPrimary600` | `colorPrimary400` |
| Button primary background | `colorBorderButtonNormalDefault` | `colorPrimary400` |
| Links | `colorPrimary600` | `colorPrimary400` |
| Focus ring | `colorPrimary600` | `colorPrimary400` |
| Selected items | `colorPrimary600` | `colorPrimary400` |
| Accent text | `colorPrimary600` | `colorPrimary400` |
| Hover states | `colorPrimary900` | `colorPrimary300` |

## If Hashes Change After Package Update

After updating `@cloudscape-design/components`, re-run the grep command above to get new hashes and update `dark-theme.css` accordingly.
