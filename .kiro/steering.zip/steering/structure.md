# Estructura del Proyecto

## Organización de Workspace

Cada prototipo debe seguir una estructura clara y consistente:

```
proyecto-nombre/
├── README.md                 # Descripción, arquitectura, instrucciones
├── .gitignore               # Ignorar archivos sensibles y temporales
├── architecture.png         # Diagrama de arquitectura (generado)
├── cdk/                     # Infraestructura como código
│   ├── app.py              # Entry point CDK
│   ├── requirements.txt    # Dependencias Python
│   ├── cdk.json           # Configuración CDK
│   └── stacks/            # Stacks de CloudFormation
│       └── main_stack.py
├── lambda/                  # Funciones Lambda (si aplica)
│   └── function_name/
│       ├── index.py
│       └── requirements.txt
├── docs/                    # Documentación adicional
│   └── design.md
└── examples/               # Ejemplos de uso, scripts de prueba
    └── test_api.py
```

## Convenciones de Nombres

- **Proyectos**: `kebab-case` (ej: `bedrock-agent-demo`)
- **Stacks CDK**: `PascalCase` (ej: `BedrockAgentStack`)
- **Funciones Lambda**: `snake_case` (ej: `process_request`)
- **Recursos AWS**: Incluir prefijo del proyecto (ej: `demo-api-gateway`)

## README Obligatorio

Cada proyecto debe incluir:

```markdown
# Nombre del Proyecto

## Descripción
[Qué hace este prototipo]

## Arquitectura
[Referencia al diagrama]

## Servicios AWS Utilizados
- Servicio 1: propósito
- Servicio 2: propósito

## Prerequisitos
- AWS CLI configurado
- CDK instalado
- Python 3.x

## Despliegue
[Pasos específicos]

## Limpieza
[Cómo eliminar recursos]

## Costos Estimados
[Estimación básica]
```

## Git

### .gitignore Estándar

```
# CDK
cdk.out/
.cdk.staging/
*.swp

# Python
__pycache__/
*.py[cod]
.venv/
*.egg-info/

# Secrets
.env
*.pem
*.key

# IDE
.idea/
.vscode/
*.code-workspace

# OS
.DS_Store
```

### Commits

- Usar mensajes descriptivos en español o inglés
- Commits atómicos y frecuentes
- No commitear credenciales o secrets

### README Sincronizado (OBLIGATORIO)

**REGLA CRÍTICA**: El README.md DEBE mantenerse sincronizado con el código desarrollado y desplegado.

#### Cuándo Actualizar el README

- Después de agregar nuevas features o funcionalidades
- Después de cambiar la arquitectura
- Después de modificar los pasos de despliegue
- Después de agregar o remover servicios AWS
- Después de cambiar configuraciones importantes

#### Qué Mantener Actualizado

- Descripción de funcionalidades actuales
- Diagrama de arquitectura (si cambió)
- Lista de servicios AWS utilizados
- Pasos de despliegue
- Variables de entorno requeridas
- Ejemplos de uso

#### Proceso

1. Al completar un feature, revisar si el README necesita actualización
2. Actualizar las secciones relevantes
3. Incluir cambios del README en el commit del feature

## Documentación

- Generar diagrama de arquitectura usando MCP AWS Diagrams
- Incluir en README referencias a documentación oficial AWS
- Documentar decisiones de diseño en `docs/design.md` si es necesario
