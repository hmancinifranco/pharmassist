# Deployment Configuration

## Infrastructure as Code - CDK Only (OBLIGATORIO)

**REGLA CRÍTICA**: Todos los cambios a la infraestructura AWS DEBEN hacerse exclusivamente a través de CDK.

### Prohibiciones

❌ **NUNCA** hacer cambios manuales a recursos AWS desde la consola
❌ **NUNCA** usar AWS CLI para crear/modificar/eliminar recursos de infraestructura
❌ **NUNCA** hacer cambios que no estén reflejados en el código CDK del workspace

### Proceso Obligatorio

1. **Modificar código CDK** en el workspace primero
2. **Ejecutar `cdk synth`** para validar los cambios
3. **Ejecutar `cdk deploy`** para aplicar los cambios
4. **Commitear los cambios** de CDK a Git

### Razón

Mantener sincronización entre el workspace y los recursos desplegados en AWS. Si se hacen cambios manuales, el estado de AWS diverge del código y causa problemas de drift.

## Git Checkpoints (OBLIGATORIO)

**REGLA CRÍTICA**: Antes de comenzar cualquier refactor importante o cambio significativo, DEBE crearse un checkpoint en Git.

### Proceso de Checkpoint

```bash
# Antes de comenzar cambios importantes
git add .
git commit -m "checkpoint: before [descripción del cambio]"

# Ejemplo
git commit -m "checkpoint: before financial-assistant-improvements refactor"
```

### Cuándo Crear Checkpoints

- Antes de refactors que afecten múltiples archivos
- Antes de cambios de arquitectura
- Antes de agregar nuevas features significativas
- Antes de modificar infraestructura CDK

### Beneficios

- Permite rollback fácil si algo sale mal
- Documenta el estado "conocido bueno" del proyecto
- Facilita code review y debugging

---

## Environment Configuration (OBLIGATORIO)

All deployment configuration MUST be centralized in a `.env` file at the project root. This file MUST be in `.gitignore` to prevent credential leaks and enable public repository sharing.

### Required `.env` File Structure

```bash
# =============================================================================
# AWS Configuration - Required for deployment
# =============================================================================

# AWS CLI profile to use for all operations (REQUIRED)
AWS_PROFILE=your-aws-profile

# AWS Region for deployment
# Note: us-west-2 required for Agent Core Runtime
AWS_REGION=us-west-2

# =============================================================================
# Resource Tagging - For cost tracking and resource identification
# =============================================================================

# Owner tag for all resources (REQUIRED)
OWNER_TAG=your-name

# Environment (dev/staging/prod)
ENVIRONMENT=dev

# =============================================================================
# Application Configuration
# =============================================================================

# DynamoDB table names
EXPENSES_TABLE_NAME=financial-assistant-expenses
USERS_TABLE_NAME=financial-assistant-users
FAMILY_GROUPS_TABLE_NAME=financial-assistant-family-groups

# Bedrock model ID
BEDROCK_MODEL_ID=anthropic.claude-3-5-sonnet-20241022-v2:0

# S3 bucket for charts (will be created with account ID suffix)
CHARTS_S3_BUCKET=financial-assistant-charts

# Agent Core Runtime ARN (populated after deployment)
AGENT_CORE_ARN=
```

### `.gitignore` Entry (REQUIRED)

The `.env` file MUST be in `.gitignore`:
```
# Secrets - NEVER commit these
.env
*.pem
*.key
```

### Loading Environment in Python

```python
import os
from dotenv import load_dotenv

# Load .env file at module start
load_dotenv()

# Access configuration
AWS_REGION = os.environ.get("AWS_REGION", "us-west-2")
EXPENSES_TABLE_NAME = os.environ.get("EXPENSES_TABLE_NAME", "financial-assistant-expenses")
```

## Resource Identification

All deployed resources MUST be properly tagged for identification and cost tracking.

### Required Tags

Apply these tags to ALL CDK stacks and resources:

| Tag Key | Value | Description |
|---------|-------|-------------|
| `Project` | `financial-assistant` | Project identifier |
| `Environment` | Value from `.env` `ENVIRONMENT` | Environment type (dev/staging/prod) |
| `Owner` | Value from `.env` `OWNER_TAG` | Who owns this deployment |
| `ManagedBy` | `cdk` | How resources are managed |

### CDK Implementation

In the main CDK app, apply tags to all stacks:

```python
import aws_cdk as cdk
from aws_cdk import Tags
import os
from dotenv import load_dotenv

load_dotenv()

app = cdk.App()

# Create stacks...
main_stack = FinancialAssistantStack(app, "FinancialAssistant-Main", ...)

# Apply tags to ALL resources in the app
Tags.of(app).add("Project", "financial-assistant")
Tags.of(app).add("Environment", os.environ.get("ENVIRONMENT", "dev"))
Tags.of(app).add("Owner", os.environ.get("OWNER_TAG", "unknown"))
Tags.of(app).add("ManagedBy", "cdk")

app.synth()
```

### Stack Naming Convention

All stack names MUST follow the pattern: `FinancialAssistant-{StackName}`

Examples:
- `FinancialAssistant-Database`
- `FinancialAssistant-Auth`
- `FinancialAssistant-WhatsApp`
- `FinancialAssistant-Charts`

### Resource Naming Convention

Resources within stacks should include the project prefix:

- S3 Bucket: `financial-assistant-charts-{account-id}`
- DynamoDB Table: `financial-assistant-expenses`
- Lambda Functions: `financial-assistant-{function-name}`
- SNS Topic: `financial-assistant-whatsapp`

### Finding Resources

To find all resources for this project:

```bash
# Using AWS CLI with tags
source .env
aws resourcegroupstaggingapi get-resources \
  --tag-filters Key=Project,Values=financial-assistant \
  --profile $AWS_PROFILE \
  --region $AWS_REGION
```

## AWS Profile and Region

When executing CDK commands, Agent Core commands, or any AWS CLI operations, ALWAYS use the profile and region configured in the `.env` file at the project root.

### Reading the Profile

Before running any AWS/CDK command:
1. Load the `.env` file to get `AWS_PROFILE` and `AWS_REGION` values
2. Include `--profile $AWS_PROFILE` in all CDK commands
3. Include `--profile $AWS_PROFILE` in all AWS CLI commands
4. Include `--region $AWS_REGION` when region matters
5. For `agentcore` CLI: use `export AWS_PROFILE` and `export AWS_DEFAULT_REGION` (does NOT support `--profile`/`--region` flags)

### Command Examples

```bash
# Load environment first (ALWAYS)
source .env

# CDK commands - always include profile
cdk synth --profile $AWS_PROFILE
cdk deploy --all --profile $AWS_PROFILE --region $AWS_REGION
cdk destroy --all --profile $AWS_PROFILE

# Agent Core commands - use environment variables (NOT --profile/--region flags)
export AWS_PROFILE=$AWS_PROFILE
export AWS_DEFAULT_REGION=$AWS_REGION
cd agentcore
agentcore launch --auto-update-on-conflict
agentcore status
agentcore invoke '{"prompt": "test"}'

# AWS CLI commands - always include profile
aws s3 ls --profile $AWS_PROFILE
aws dynamodb list-tables --profile $AWS_PROFILE --region $AWS_REGION
aws bedrock list-foundation-models --profile $AWS_PROFILE --region $AWS_REGION
```

### Loading Environment Variables

Before running commands, load the `.env` file:

```bash
# Option 1: Source the file
source .env

# Option 2: Export all variables
export $(grep -v '^#' .env | xargs)

# Then run commands
cdk deploy --all --profile $AWS_PROFILE --region $AWS_REGION
```

## Region Configuration

- Default region for Agent Core Runtime: `us-west-2` (required for Agent Core)
- This is configured in `.env` as `AWS_REGION=us-west-2`
- Can be overridden by setting `AWS_REGION` in the `.env` file for other services
