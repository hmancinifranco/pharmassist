---
inclusion: always
---

# Bash Heredoc Restriction

## Rule

NEVER use heredoc syntax (`<<`) in `executeBash` tool commands. This includes all heredoc variants:
- `<< EOF`
- `<< 'EOF'`
- `<< DELIMITER`

## Reason

Heredoc syntax causes console breakage and execution failures. The tool cannot properly parse multi-line input with heredoc delimiters.

## Alternatives

### For Python Scripts

Use `fsWrite` to create the file, then execute it:

```python
# Step 1: Create file with fsWrite
fsWrite(path="script.py", text="print('hello')")

# Step 2: Execute with executeBash
executeBash(command="python3 script.py")
```

### For Code Modifications

Use dedicated code editing tools instead of bash:
- `strReplace` - String-based replacements
- `editCode` - AST-based code edits
- `fsWrite` - Create new files
- `fsAppend` - Append to existing files

### For Multi-line Commands

Option 1: Use semicolons for simple sequences
```bash
cd /tmp; echo "test" > file.txt; cat file.txt
```

Option 2: Make multiple `executeBash` calls in sequence

## Examples

❌ FORBIDDEN:
```bash
python3 << 'EOF'
print("hello")
EOF
```

✅ CORRECT:
```bash
# Use fsWrite tool first, then execute
python3 script.py
```

❌ FORBIDDEN:
```bash
cat > config.json << 'EOF'
{"key": "value"}
EOF
```

✅ CORRECT:
```python
# Use fsWrite tool
fsWrite(path="config.json", text='{"key": "value"}')
