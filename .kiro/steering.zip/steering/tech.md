# Stack Tecnológico

## Infraestructura

- **IaC**: AWS CDK (Python) - preferido para prototipos rápidos
- **Cloud**: AWS exclusivamente
- **Región**: Usar `us-east-1` por defecto (más servicios disponibles)

## CDK Best Practices

### Configuración Centralizada (OBLIGATORIO)

Todos los valores configurables deben definirse como constantes al inicio del archivo de stack, NO hardcodeados en los recursos. Esto permite:
- Cambios fáciles sin buscar en todo el código
- CDK detecta cambios en variables de entorno correctamente
- Documentación inline de opciones disponibles

```python
# =============================================================================
# CONFIGURATION - Change these values to customize the deployment
# =============================================================================

# Bedrock model for image analysis
# Options: "us.amazon.nova-lite-v1:0", "us.amazon.nova-pro-v1:0", etc.
BEDROCK_MODEL_ID = "us.amazon.nova-lite-v1:0"

# Lambda memory and timeout defaults
LAMBDA_MEMORY_MB = 512
LAMBDA_TIMEOUT_SECONDS = 30

# Feature flags
ENABLE_XRAY_TRACING = True
```

Luego usar las constantes en los recursos:

```python
my_lambda = lambda_.Function(
    self, "MyFunction",
    environment={"MODEL_ID": BEDROCK_MODEL_ID},
    memory_size=LAMBDA_MEMORY_MB,
    timeout=Duration.seconds(LAMBDA_TIMEOUT_SECONDS),
)
```

**NUNCA** hardcodear valores directamente en los recursos:
```python
# ❌ MAL - hardcodeado
environment={"MODEL_ID": "us.amazon.nova-lite-v1:0"}

# ✅ BIEN - usando constante
environment={"MODEL_ID": BEDROCK_MODEL_ID}
```

## Herramientas de Desarrollo

- **Control de versiones**: Git
- **Kiro Powers**: Instalados y disponibles
  - `cloud-architect`: Para CDK y arquitectura AWS
  - `aws-agentcore`: Para desarrollo de agentes
  - `strands`: Para agentes con LLMs

## MCP Servers Disponibles

Usar estos MCP servers para consultar documentación oficial:

- **AWS Documentation**: Búsqueda y lectura de docs oficiales
- **AWS Knowledge**: Disponibilidad regional, servicios AWS
- **AWS CDK**: Guías y patrones de CDK
- **AWS Diagrams**: Generación de diagramas de arquitectura

## Comandos Comunes

### CDK
```bash
# Inicializar proyecto CDK
cdk init app --language python

# Instalar dependencias
pip install -r requirements.txt

# Sintetizar CloudFormation
cdk synth

# Desplegar
cdk deploy

# Destruir recursos
cdk destroy
```

### Git
```bash
# Inicializar repo
git init

# Commit inicial
git add .
git commit -m "Initial commit"

# Preparar para GitHub
git branch -M main
```

### Python (si aplica)
```bash
# Crear entorno virtual
python3 -m venv .venv
source .venv/bin/activate

# Instalar dependencias
pip install -r requirements.txt
```

## Validación

Antes de finalizar un prototipo:
1. Verificar contra documentación oficial AWS usando MCP
2. Probar despliegue completo
3. Documentar arquitectura con diagrama
4. Incluir README con instrucciones claras
